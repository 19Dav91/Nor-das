'use strict';
// 156.1 Сделайте функцию, выводящую в консоль ваше имя.

function name() {
    console.log('David');
}
name()